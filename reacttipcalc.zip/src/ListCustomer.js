import React from "react";

export default class ListCustomer extends React.Component {
  render() {
    return (
      <li key={customer.index}>
        {d.name} offering a tip of {d.tip} rupee
      </li>
    );
  }
}
