import React from "react";
import "./styles.css";

export default class Select extends React.Component {
  constructor(props) {
    super(props);

    this.handleSelectChange = this.handleSelectChange.bind(this);
  }
  handleSelectChange(event) {
    this.props.onSelectorChange(event.target.value);
  }
  render() {
    return (
      <div>
        <p></p>
        <p>How was the service</p>
        <select onChange={this.handleSelectChange}>
          <option disabled selected value="">
            Choose .....
          </option>
          <option value="0.2">Excellent (20%)</option>
          <option value="0.1">Moderate (10%)</option>
          <option value="0.05">Bad (5%)</option>
        </select>
      </div>
    );
  }
}
