import React from "react";
import Input from "./Input";
import Select from "./Select";

function Header(props) {
  return (
    <div>
      <h1>{props.title}</h1>
      <h5>{props.content}</h5>
    </div>
  );
}
export default class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      bill: "",
      service: "",
      people: "",
      tipAmount: "",
      tipResultDisplay: "none",
      calculatePressed: false,
      visible: false,
      list: [
      ],
      visibleDiv: false,
      totalCustomer: 0,
      totalTip: 0
    };

    this.handleBillChange = this.handleBillChange.bind(this);
    this.handleServiceChange = this.handleServiceChange.bind(this);
    this.handlePeopleChange = this.handlePeopleChange.bind(this);
    this.handleCalculateTip = this.handleCalculateTip.bind(this);
    this.handleCalculateTipCustomer = this.handleCalculateTipCustomer.bind(
      this
    );
    this.handleToggle = this.handleToggle.bind(this);
  }

  handleBillChange(event) {
    this.setState({ bill: event });
  }

  handleServiceChange(event) {
    this.setState({ service: event });
  }

  handlePeopleChange(event) {
    this.setState({ people: event });
  }

  handleCalculateTip() {
    if (!isNaN(this.state.bill) && !isNaN(this.state.service)) {
      if (this.state.bill > 0) {
        if (this.state.service > 0) {
          var tipAmount = this.state.bill * this.state.service;

          this.setState((prevState) => ({
            calculatePressed: true,
            tipResultDisplay: "block",
            tipAmount: tipAmount,
            list: [
              ...prevState.list,
              { index: Math.random(), name: this.state.people, tip: tipAmount }
            ],
            visible: true
          }));
        }
      }
    }
  }
  handleCalculateTipCustomer() {
    var total = 0;
    if (this.state.list.length) {
      this.state.list.map((d) => (total = total + d.tip));
      this.setState((prevState) => ({
        totalCustomer: this.state.list.length,
        totalTip: total,
        visibleDiv: !prevState.visibleDiv
      }));
    }
  }
  handleToggle() {
    this.setState((prevState) => ({
      visible: !prevState.visible
    }));
  }

  render() {
    return (
      <div className="content">
        <Header title="Tip Calculator" content="Built in react" />
        <Input
          label="Enter your bill amount"
          input={{
            placeholder: "Bill Amount",
            type: "bill"
          }}
          onTextChange={this.handleBillChange}
          prefix="Rs."
        />
        <Select
          selectInput={{
            type: "service"
          }}
          onSelectorChange={this.handleServiceChange}
          inputCustomer={{
            placeholder: "Customer name",
            type: "people"
          }}
          onNameChange={this.handlePeopleChange}
        />

        <div>
          <Input
            input={{
              placeholder: "Enter Customer name",
              type: "people"
            }}
            onTextChange={this.handlePeopleChange}
          />
          <button onClick={this.handleCalculateTip}>Add Customer</button>
        </div>
        <div>
          {this.state.visible ? (
            <>
              {this.state.list.length ? (
                <ul>
                  {this.state.list.map((d) => (
                    <li key={d.index}>
                      {d.name} offering a tip of {d.tip} rupee
                    </li>
                  ))}
                </ul>
              ) : null}
              <button onClick={this.handleCalculateTipCustomer}>
                Calculate Tip & Customer
              </button>

              <div>
                {this.state.visibleDiv ? (
                  <table border="1" align="center">
                    <thead>
                      <tr>
                        <td>Total Customer</td>
                        <td>Total tip</td>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>{this.state.totalCustomer}</td>
                        <td>{this.state.totalTip}</td>
                      </tr>
                    </tbody>
                  </table>
                ) : null}
              </div>
            </>
          ) : null}
          <div>
            <footer>@2020 tip calc</footer>
            </div>
        </div>
      </div>
    );
  }
}


